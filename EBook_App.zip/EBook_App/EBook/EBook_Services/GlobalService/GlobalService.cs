﻿using EBook_Data.DataAccess;
using EBook_Data.DatabaseContext;
using EBook_Models.App_Models;
using EBook_Models.Data_Model;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Configuration;
using Microsoft.VisualBasic;
using System.Data;

namespace EBook_Services.GlobalService
{
    
}
