﻿using EBook_Models.App_Models;
using EBook_Models.Data_Model;
using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EBook_Services.GlobalService
{
    public interface IGlobalService
    {
    }

    

    
}
